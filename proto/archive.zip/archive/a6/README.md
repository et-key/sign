# Sign言語インタープリタ - Phase 4まで実装完了

Sign言語のRacket `#lang`実装です。仕様書 `documents\ja-jp\specification\Interpreter_Specification_ja-jp.md` に基づいています。

## 実装済みの機能

### コアファイル
- **info.rkt** - パッケージ情報とRacket依存関係
- **main.rkt** - `#lang sign` のエントリポイント
- **reader.rkt** - Sign構文リーダー（トークナイザ + 中置→前置変換）
- **runtime.rkt** - ランタイムライブラリ（演算、Stream操作）
- **repl.rkt** - 対話環境（REPL）

### 実装されている機能

#### 演算子
- **算術演算**: `+`, `-`, `*`, `/`, `%`, `^`, `!` (階乗)
- **比較演算**: `<`, `<=`, `=`, `>=`, `>`, `!=` （値返却型）
- **論理演算**: `&` (and), `|` (or), `;` (xor), `!` (not) （短絡評価対応）
- **定義演算**: `:` (定義)

#### リテラル
- 数値: `42`, `-3.14`
- 16進数: `0xAF`
- 8進数: `0o77`
- 2進数: `0b1010`
- 文字列: `` `文字列` ``
- Unit（空リスト）: `_`

#### Stream操作
- 範囲リスト: `[1 ~ 5]` (有限), `[1 ~ ]` (無限)
- MAP/FOLD操作のための基盤

#### パース機能
- 中置記法からS式（前置記法）への変換
- 演算子優先順位の処理
- 右結合/左結合の対応

#### 制御構造（Phase 4）
- **ブロック構文**: インデントベースのコードブロック
- **条件分岐 (match_case)**: `Expr : Expr` パターンの自動 `cond` 変換
- **暗黙的else**: 条件分岐の最後の式が自動的に `else` 節に
- **混合コンテンツ**: 定義と条件分岐の組み合わせ

## 使用方法

### 前提条件
Racketがインストールされている必要があります：
- [Racket公式サイト](https://racket-lang.org/) からダウンロード
- インストール後、`racket`コマンドが利用可能であることを確認

### テストの実行

#### プロジェクトルートから実行する場合

```powershell
# プロジェクトルート（sign ディレクトリ）に移動
cd C:\Users\ym_st\work_vscode\sign

# 基本テストの実行
racket proto\a6\tests\test-basic.rkt

# 関数機能テストの実行（Phase 2）
racket proto\a6\tests\test-functions.rkt

# Stream機能テストの実行（Phase 3）
racket proto\a6\tests\test-streams.rkt

# 制御構造テストの実行（Phase 4）
racket proto\a6\tests\test-block.rkt
racket proto\a6\tests\test-match.rkt
racket proto\a6\tests\test-control.rkt
```

#### `proto\a6` ディレクトリから実行する場合

```powershell
# proto\a6 ディレクトリに移動
cd C:\Users\ym_st\work_vscode\sign\proto\a6

# 基本テストの実行
racket tests\test-basic.rkt

# 関数機能テストの実行（Phase 2）
racket tests\test-functions.rkt

# Stream機能テストの実行（Phase 3）
racket tests\test-streams.rkt

# 制御構造テストの実行（Phase 4）
racket tests\test-block.rkt
racket tests\test-match.rkt
racket tests\test-control.rkt
```

### REPLの起動

#### プロジェクトルートから実行する場合

```powershell
# REPLを起動
racket proto\a6\repl.rkt
```

#### `proto\a6` ディレクトリから実行する場合

```powershell
# REPLを起動
racket repl.rkt
```

REPLコマンド：
- `:quit` - 終了
- `:help` - ヘルプ表示
- `Ctrl+C` - 強制終了

### Sign言語ファイルの実行

現在、`#lang sign`を使用するにはパッケージのインストールが必要です：

```powershell
cd proto\a6
raco pkg install
```

その後、Sign言語ファイル（例：`example.sn`）を以下のように記述：

```scheme
#lang sign

` 変数定義
x : 42
y : 10

` 演算
sum : x + y

` 関数定義（Phase 2）
add : x y ? x + y
inc : [+ 1]

` 関数適用
result : add 3 5
next : inc 10

` リスト操作とStream（Phase 3）
nums : 1, 2, 3, 4, 5
doubled : [* 2,] nums
total : [+] nums

` 無限リスト
naturals : [1 ~]
first-5 : naturals ~

` 制御構造（Phase 4）
` 条件分岐
classify : x ?
    x < 0 : `negative`
    x = 0 : `zero`
    x > 0 : `positive`

` 再帰関数
fact : n ?
    n <= 1 : 1
    n * (fact (n - 1))
```

## プロジェクト構造

```
proto/a6/
├── info.rkt              # パッケージ情報
├── main.rkt              # #lang エントリポイント
├── reader.rkt            # Sign構文リーダー
├── runtime.rkt           # ランタイムライブラリ
├── repl.rkt              # REPL実装
├── example.sn            # サンプルファイル
└── tests/
    ├── test-basic.rkt     # 基本テスト
    ├── test-functions.rkt # 関数機能テスト（Phase 2）
    ├── test-streams.rkt   # Stream機能テスト（Phase 3）
    ├── test-block.rkt     # ブロック構文テスト（Phase 4）
    ├── test-match.rkt     # 条件分岐テスト（Phase 4）
    └── test-control.rkt   # 制御構造統合テスト（Phase 4）
```

## 今後の実装予定（Phase 5以降）

- **Phase 5**: モジュールシステム
  - Export/Import演算子
  - 名前空間管理

- **将来の拡張**:
  - パターンマッチと代数的データ型
  - マクロシステム
  - 型システム（オプション）

## テスト内容

`tests/test-basic.rkt`では以下をテスト：
- 数値リテラルのパース
- Unit（空リスト）
- 算術演算と優先順位
- 比較演算（値返却型）
- 論理演算（短絡評価）
- Stream操作（範囲リスト）
- 階乗計算

## 注意事項

- Phase 1-4まで実装完了：基本演算、関数、Stream、制御構造
- 詳細なステータスは `STATUS.md` を参照

## 参考資料

- 仕様書: `documents\ja-jp\specification\Interpreter_Specification_ja-jp.md`
- [Racket公式ドキュメント](https://docs.racket-lang.org/)
- [Beautiful Racket](https://beautifulracket.com/) - `#lang`実装チュートリアル
